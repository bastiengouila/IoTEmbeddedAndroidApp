package android.digi.com.gsgsample;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.content.Intent;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.android.volley.*;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

public class DataBaseActivity extends Activity {

    private Button BackButton;

    Intent intentMainDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_database);
        intentMainDatabase = new Intent();
        initializeControls();
    }
    private void SendingToDatabase(final String strsensor, final String strvalue){
        // Instantiate the RequestQueue.
        RequestQueue queue = Volley.newRequestQueue(this);
        String url ="https://iot-project-metropolia.eu-gb.mybluemix.net/api/group_9";
        // Post the Parameters to the provided URL. Sending
        StringRequest stringRequest2 = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // Display the first 500 characters of the response string.
                        //mTextView.setText("Response is: ");
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                //mTextView.setText(error.getMessage());
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("value", strvalue);
                params.put("sensor_name", strsensor);
                return params;
            }

            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String,String>params = new HashMap<>();
                params.put("Authorization","Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJuYW1lIjoiR1JPVVBfOSJ9.Gp73S7NH1sMEW494cObPiC_cu60w1ASqDFzG35GL5bo");
                //..add other headers
                return params;
            }


        };
// Add the request to the RequestQueue.
        queue.add(stringRequest2);

    }

    private void ReceivingFromDatabase(){
        // Instantiate the RequestQueue.
        RequestQueue queue = Volley.newRequestQueue(this);
        String url = "https://iot-project-metropolia.eu-gb.mybluemix.net/api/group_9";

// Request a string response from the provided URL.Receiving
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // Display the first 500 characters of the response string.
                        //mTextView.setText("Response is: "+ response);
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                //mTextView.setText(error.getMessage());
            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("Authorization", "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJuYW1lIjoiR1JPVVBfOSJ9.Gp73S7NH1sMEW494cObPiC_cu60w1ASqDFzG35GL5bo");
                //..add other headers
                return params;
            }
        };
// Add the request to the RequestQueue.
        queue.add(stringRequest);

    }

    @Override
    protected void onDestroy() {

        super.onDestroy();
    }

    private void initializeControls() {
        // Declare views by retrieving them with the ID.
        BackButton = (Button)findViewById(R.id.ButtonBackData);

        // Set focus to the button.
        BackButton.setFocusable(true);
        BackButton.requestFocus();

        BackButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                handleBackButtonPressed();
            }
        });
    }
    private void handleBackButtonPressed() {
        String strKey1 = "strIntentExtraName";
        String strKey2 = "SwitchesValues";
        intentMainDatabase.putExtra(strKey1,"DATABASE");
        DataBaseActivity.this.setResult(RESULT_OK, intentMainDatabase);
        finish();
    }
}
