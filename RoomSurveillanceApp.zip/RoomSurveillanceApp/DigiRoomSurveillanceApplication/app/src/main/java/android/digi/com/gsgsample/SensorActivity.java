package android.digi.com.gsgsample;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewDebug;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;

public class SensorActivity extends Activity {

    private Button BackButton;
    private Switch DoorSwitch;
    private Switch TempSwitch;
    private Switch LightSwitch;
    private Switch HumiSwitch;

    Intent intentMainSensor;

    private boolean bSwitches[] = new boolean[4];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sensor);
        intentMainSensor = new Intent();
        initializeControls();
    }
    @Override
    protected void onDestroy() {

        super.onDestroy();
    }

    private void initializeControls() {
        // Declare views by retrieving them with the ID.
        BackButton = (Button)findViewById(R.id.ButtonBackSen);
        DoorSwitch = (Switch)findViewById(R.id.SwitchDoor);
        TempSwitch = (Switch)findViewById(R.id.SwitchTempe);
        LightSwitch = (Switch)findViewById(R.id.SwitchLight);
        HumiSwitch = (Switch)findViewById(R.id.SwitchHumi);
        // Set focus to the button.
        BackButton.setFocusable(true);
        BackButton.requestFocus();

        BackButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                handleBackButtonPressed();
            }
        });

        DoorSwitch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                handleDoorSwitchClick();
            }
        });
        TempSwitch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                handleTempSwitchClick();
            }
        });
        LightSwitch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                handleLightSwitchClick();
            }
        });
        HumiSwitch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                handleHumiSwitchClick();
            }
        });
    }
    private void handleBackButtonPressed(){
        String strKey1 = "strIntentExtraName";
        String strKey2 = "SwitchesValues";
        intentMainSensor.putExtra(strKey1,"SENSOR");
        intentMainSensor.putExtra(strKey2,bSwitches);
        SensorActivity.this.setResult(RESULT_OK, intentMainSensor);
        finish();
    }
    private void handleDoorSwitchClick() {
        bSwitches[0]= DoorSwitch.isChecked();
    }
    private void handleTempSwitchClick() {
        bSwitches[1]= TempSwitch.isChecked();
    }
    private void handleLightSwitchClick() {
        bSwitches[2]= LightSwitch.isChecked();
    }
    private void handleHumiSwitchClick() {
        bSwitches[3]= HumiSwitch.isChecked();
    }

}
