package android.digi.com.gsgsample;


import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import android.app.Activity;
import android.content.Intent;
import android.hardware.Camera;
import android.hardware.Camera.PictureCallback;
import android.hardware.Camera.ShutterCallback;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.SurfaceHolder.Callback;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

/**
 * Camera sample application.
 *
 * <p>This example displays video captured by the camera and allows to take
 * photographs using the Camera API.</p>
 *
 * <p>For a complete description on the example, refer to the 'README.md' file
 * included in the example directory.</p>
 */
public class CameraActivity extends Activity implements Callback {
    // Constants.
    private static final String TAG = "CameraSampleActivity";

    // Variables.
    private Button BackButton;
    private SurfaceView SurfaceCamera;

    Intent intentMainCamera;
    private Camera camera;
    private boolean mPreviewing;

    ShutterCallback shutterCallback = new ShutterCallback() {
        @Override
        public void onShutter() {
        }
    };

    /** Handles data for raw picture */
    PictureCallback rawCallback = new PictureCallback() {
        @Override
        public void onPictureTaken(byte[] data, Camera camera) {
        }
    };

    /** Handles data for jpeg picture */
    PictureCallback jpegCallback = new PictureCallback() {
        @Override
        public void onPictureTaken(byte[] data, Camera camera) {
            FileOutputStream outStream;
            if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
                try {
                    outStream = new FileOutputStream(String.format(
                            Environment.getExternalStorageDirectory().getPath() + "/%d.jpg", System.currentTimeMillis()));
                    outStream.write(data);
                    outStream.close();
                    Log.d(TAG, "Picture taken - size: " + data.length + " bytes");
                    Toast toast = Toast.makeText(getApplicationContext(), "Photograph saved in SD card.", Toast.LENGTH_LONG);
                    toast.show();
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else {
                Toast toast = Toast.makeText(getApplicationContext(),
                        "No SD card mounted. Photograph cannot be saved.", Toast.LENGTH_LONG);
                toast.show();
            }

            startPreview();
        }
    };

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_camera);
        BackButton = (Button)findViewById(R.id.ButtonBackCam);
        //int i = Camera.getNumberOfCameras();
        //BackButton.setText(String.valueOf(i));
        SurfaceView SurfaceCamera = (SurfaceView) findViewById(R.id.Camera);
        SurfaceHolder holder = SurfaceCamera.getHolder();
        holder.addCallback(this);
        intentMainCamera = new Intent();
        BackButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                camera.takePicture(shutterCallback, rawCallback, jpegCallback);
                mPreviewing = false;
                handleBackButtonPressed();
            }
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        camera.stopPreview();
        camera.release();
        mPreviewing = false;
    }

    @Override
    protected void onResume() {
        super.onResume();
        camera = Camera.open();
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        try {
            camera.setPreviewDisplay(holder);
        } catch (IOException e) {
            e.printStackTrace();
        }
        startPreview();

    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
    }

    /**
     * Starts video preview.
     */
    private void startPreview() {
        if (mPreviewing)
            return;

        Thread t = new Thread(){
            @Override
            public void run() {
                camera.startPreview();
            }
        };
        t.start();

        mPreviewing = true;
    }

    private void handleBackButtonPressed() {
        String strKey1 = "strIntentExtraName";
        intentMainCamera.putExtra(strKey1,"CAMERA");
        CameraActivity.this.setResult(RESULT_OK, intentMainCamera);
        finish();
    }
}
