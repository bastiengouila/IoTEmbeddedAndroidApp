/**
 * Copyright (c) 2016, Digi International Inc. <support@digi.com>
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */

package android.digi.com.gsgsample;


import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.hardware.Camera;
import android.os.Bundle;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.StringTokenizer;
import java.util.regex.Pattern;
import java.math.BigInteger;

import com.android.volley.*;
import java.util.HashMap;
import java.util.Map;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.Request;

import com.digi.android.gpio.GPIO;
import com.digi.android.gpio.GPIOException;
import com.digi.android.gpio.GPIOManager;
import com.digi.android.gpio.GPIOMode;
import com.digi.android.gpio.GPIOValue;
import com.digi.android.i2c.I2C;
import com.digi.android.i2c.I2CManager;


/**
 * GSG Sample application.
 *
 * <p>This example demonstrates the usage of the GPIO
 * API by blinking the User 0 LED of the SBC device.</p>
 *
 * <p>For a complete description on the example, refer to the 'README.md' file
 * included in the example directory.</p>
 */
public class MainActivity extends Activity {

	// Constants.
	private final static int GPIO_DOOR = 60;//EXP_GPIO_4 pin 10 GPIO_2_28 pin number = ((port-1)*32)+pin
	private final static int GPIO_LIGHT = 56;//EXP_GPIO_3 pin 9 GPIO_2_24 pin number = ((port-1)*32)+pin
	private final static int MIN_PERIOD = 100;
	private final static int MAX_PERIOD = 10000;

	// Variables.
	private GPIO DoorGPIO;
	private GPIO LightGPIO;

	private boolean bSensorEnableValues[] = new boolean[4];

	private Button SensorsButton;
	private Button CameraButton;
	private Button DataBaseButton;
	private TextView TxtViewDoor;
	private TextView TxtViewDoorData;
	private TextView TxtViewTemp;
	private TextView TxtViewTempData;
	private TextView TxtViewLight;
	private TextView TxtViewLightData;
	private TextView TxtViewHumidity;
	private TextView TxtViewHumidityData;

	// Variables.
	private final ArrayList<HexRow> hexRows = new ArrayList<>();

	int iSendDataTime= 0;

	private I2CManager i2cManager;
	private I2C i2cInterface;
	Intent intentSensor;
	Intent intentCamera;
	Intent intentDatabase;

	private Thread SensorUpdateThread;

	private boolean bUpdate = false;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		// Initialize application control and GPIO.
		initializeControls();
		initializeGPIOs();
		intentSensor = new Intent(this, SensorActivity.class);
		intentCamera = new Intent(this, CameraActivity.class);
		intentDatabase = new Intent(this, DataBaseActivity.class);
		bSensorEnableValues[0] = false;
		bSensorEnableValues[1] = false;
		bSensorEnableValues[2] = false;
		bSensorEnableValues[3] = false;
	}

	@Override
	protected void onDestroy() {

		DoorGPIO = null;
		LightGPIO = null;
		super.onDestroy();
	}

	@Override
	protected void onResume() {
		super.onResume();

	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		//Recover the data
		String strSensor = "SENSOR";
		String strKey = data.getExtras().getString("strIntentExtraName");
		if(strKey.equals(strSensor)){
			InitializeSensorThread();
			boolean bSensorKeys[] = data.getExtras().getBooleanArray("SwitchesValues");
			for(int i=0;i<bSensorEnableValues.length;i++){bSensorEnableValues[i]=bSensorKeys[i];}
			if(bSensorEnableValues[0]){TxtViewDoorData.setTextColor(0xFF000000);}
			else{TxtViewDoorData.setTextColor(0x80808080);}
			if(bSensorEnableValues[1]){TxtViewTempData.setTextColor(0xFF000000);}
			else{TxtViewTempData.setTextColor(0x80808080);}
			if(bSensorEnableValues[2]){TxtViewLightData.setTextColor(0xFF000000);}
			else{TxtViewLightData.setTextColor(0x80808080);}
			if(bSensorEnableValues[3]){TxtViewHumidityData.setTextColor(0xFF000000);}
			else{TxtViewHumidityData.setTextColor(0x80808080);}
		}
		InitializeSensorThread();
	}

	/**
	 * Initializes the LED GPIO.
	 */
	private void initializeGPIOs() {
		// Get the GPIO manager.
		GPIOManager gpioManager = new GPIOManager(this);
		try {
			DoorGPIO = gpioManager.createGPIO(GPIO_DOOR, GPIOMode.INPUT);
			LightGPIO = gpioManager.createGPIO(GPIO_LIGHT, GPIOMode.INPUT);
		} catch (GPIOException e) {
			displayError("Error initializing GPIO: " + e.getMessage());
		}
	}

	/**
	 * Initializes application controls.
	 */
	private void initializeControls() {
		// Declare views by retrieving them with the ID.
		CameraButton = (Button) findViewById(R.id.ButtonCamera);
		SensorsButton = (Button) findViewById(R.id.ButtonSensor);
		DataBaseButton = (Button) findViewById(R.id.ButtonDataBase);
		TxtViewDoor = (TextView) findViewById(R.id.TextViewColumn10);
		TxtViewDoorData = (TextView) findViewById(R.id.TextViewColumn11);
		TxtViewTemp = (TextView) findViewById(R.id.TextViewColumn20);
		TxtViewTempData = (TextView) findViewById(R.id.TextViewColumn21);
		TxtViewLight = (TextView) findViewById(R.id.TextViewColumn30);
		TxtViewLightData = (TextView) findViewById(R.id.TextViewColumn31);
		TxtViewHumidity = (TextView) findViewById(R.id.TextViewColumn40);
		TxtViewHumidityData = (TextView) findViewById(R.id.TextViewColumn41);

		// Set focus to the button.
		SensorsButton.setFocusable(true);
		SensorsButton.requestFocus();
		CameraButton.setFocusable(true);
		CameraButton.requestFocus();
		DataBaseButton.setFocusable(true);
		DataBaseButton.requestFocus();

		SensorsButton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				handleSensorButtonPressed();
			}
		});
		CameraButton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				handleCameraButtonPressed();
			}
		});
		DataBaseButton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				handleDataBaseButtonPressed();
			}
		});

	}

	//Site:  https://iot-project-metropolia.eu-gb.mybluemix.net/api/group_9
	//token: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJuYW1lIjoiR1JPVVBfOSJ9.Gp73S7NH1sMEW494cObPiC_cu60w1ASqDFzG35GL5bo

	private void SendingToDatabase(final String strsensor, final String strvalue){
		// Instantiate the RequestQueue.
		RequestQueue queue = Volley.newRequestQueue(this);
		String url ="https://iot-project-metropolia.eu-gb.mybluemix.net/api/group_9";
		// Post the Parameters to the provided URL. Sending
		StringRequest stringRequest2 = new StringRequest(Request.Method.POST, url,
				new Response.Listener<String>() {
					@Override
					public void onResponse(String response) {
						// Display the first 500 characters of the response string.
						//mTextView.setText("Response is: ");
					}
				}, new Response.ErrorListener() {
			@Override
			public void onErrorResponse(VolleyError error) {
				//mTextView.setText(error.getMessage());
			}
		}){
			@Override
			protected Map<String, String> getParams() throws AuthFailureError {
				Map<String, String> params = new HashMap<String, String>();
				params.put("value", strvalue);
				params.put("sensor_name", strsensor);
				return params;
			}

			@Override
			public Map<String, String> getHeaders() throws AuthFailureError {
				Map<String,String>params = new HashMap<>();
				params.put("Authorization","Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJuYW1lIjoiR1JPVVBfOSJ9.Gp73S7NH1sMEW494cObPiC_cu60w1ASqDFzG35GL5bo");
				//..add other headers
				return params;
			}


		};
// Add the request to the RequestQueue.
		queue.add(stringRequest2);

	}

	private void ReceivingFromDatabase(){
		// Instantiate the RequestQueue.
		RequestQueue queue = Volley.newRequestQueue(this);
		String url = "https://iot-project-metropolia.eu-gb.mybluemix.net/api/group_9";

// Request a string response from the provided URL.Receiving
		StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
				new Response.Listener<String>() {
					@Override
					public void onResponse(String response) {
						// Display the first 500 characters of the response string.
						//mTextView.setText("Response is: "+ response);
					}
				}, new Response.ErrorListener() {
			@Override
			public void onErrorResponse(VolleyError error) {
				//mTextView.setText(error.getMessage());
			}
		}) {
			@Override
			public Map<String, String> getHeaders() throws AuthFailureError {
				Map<String, String> params = new HashMap<>();
				params.put("Authorization", "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJuYW1lIjoiR1JPVVBfOSJ9.Gp73S7NH1sMEW494cObPiC_cu60w1ASqDFzG35GL5bo");
				//..add other headers
				return params;
			}
		};
// Add the request to the RequestQueue.
		queue.add(stringRequest);

	}

	private void handleSensorButtonPressed() {
			//intent.putExtra(EXTRA_MESSAGE, message);
			StopSensorThread();
			startActivityForResult(intentSensor, 1);
	}
	private void handleCameraButtonPressed() {
			//intent.putExtra(EXTRA_MESSAGE, message);
		StopSensorThread();
		startActivityForResult(intentCamera, 1);
	}
	private void handleDataBaseButtonPressed() {
			//intent.putExtra(EXTRA_MESSAGE, message);
		//StopSensorThread();
		//startActivityForResult(intentDatabase, 1);
		double temp =0;
		double hum =0;
		int door =0;
		int light =0;
		try {
			GPIOValue DoorValue;
			GPIOValue LightValue;

			if (bSensorEnableValues[0]) {
				DoorValue = DoorGPIO.getValue();
				door = DoorValue.getValue();
				if(String.valueOf(door).equals("1")){
					TxtViewDoorData.setText("Open");
				}
				else{
					TxtViewDoorData.setText("Close");
				}
			}
			if (bSensorEnableValues[1]) {
				temp = readValueT();
				TxtViewTempData.setText(String.valueOf(temp + "°C"));
			}
			if (bSensorEnableValues[2]) {
				LightValue = LightGPIO.getValue();
				light = LightValue.getValue();
				if(String.valueOf(light).equals("1")){
					TxtViewLightData.setText("Off");
				}
				else{
					TxtViewLightData.setText("On");
				}
			}
			if (bSensorEnableValues[3]) {
				hum = readValueH();
				TxtViewHumidityData.setText(String.valueOf(hum) + "%");
			}

		}catch (final GPIOException e) {
			bUpdate = false;
			runOnUiThread(new Runnable() {
				@Override
				public void run() {
					displayError("Error setting GPIO value: " + e.getMessage());
				}
			});
		}
		try {
			URL url = new URL("https://api.thingspeak.com/update?api_key=Y64N1A63PRYL402B&field1=" +temp+"&field2="+hum+"&field3="+light+"&field4="+door);
			HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
			urlConnection.getInputStream();
			urlConnection.disconnect();
		} catch (Exception e) {
		}

	}

	private void InitializeSensorThread(){
		bUpdate = true;

		SensorUpdateThread = new Thread() {
		@Override
		public void run() {

			while (bUpdate) {
				if (!bUpdate)
					break;
				try {
					double temp =0;
					double hum =0;
					int door =0;
					int light =0;
					try {
						GPIOValue DoorValue;
						GPIOValue LightValue;

						if (bSensorEnableValues[0]) {
							DoorValue = DoorGPIO.getValue();
							door = DoorValue.getValue();
							if(String.valueOf(door).equals("1")){
								TxtViewDoorData.setText("Open");
							}
							else{
								TxtViewDoorData.setText("Close");
							}
						}
						if (bSensorEnableValues[1]) {
							temp = readValueT();
							TxtViewTempData.setText(String.valueOf(temp + "°C"));
						}
						if (bSensorEnableValues[2]) {
							LightValue = LightGPIO.getValue();
							light = LightValue.getValue();
							if(String.valueOf(light).equals("1")){
								TxtViewLightData.setText("Off");
							}
							else{
								TxtViewLightData.setText("On");
							}
						}
						if (bSensorEnableValues[3]) {
							hum = readValueH();
							TxtViewHumidityData.setText(String.valueOf(hum) + "%");
						}

					} catch (final GPIOException e) {
						bUpdate = false;
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								displayError("Error setting GPIO value: " + e.getMessage());
							}
						});
					}

					if(iSendDataTime==9) {
						try {
							URL url = new URL("https://api.thingspeak.com/update?api_key=Y64N1A63PRYL402B&field1=" +temp+"&field2="+hum+"&field3="+light+"&field4="+door);
							HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
							urlConnection.getInputStream();
							urlConnection.disconnect();
						} catch (Exception e) {
						}
					}
				}catch(Exception e){
					runOnUiThread(new Runnable() {
						@Override
						public void run() {
							double temp =0;
							double hum =0;
							int door =0;
							int light =0;
							try {
								GPIOValue DoorValue;
								GPIOValue LightValue;

								if (bSensorEnableValues[0]) {
									DoorValue = DoorGPIO.getValue();
									door = DoorValue.getValue();
									if(String.valueOf(door).equals("1")){
										TxtViewDoorData.setText("Open");
									}
									else{
										TxtViewDoorData.setText("Close");
									}
								}
								if (bSensorEnableValues[1]) {
									temp = readValueT();
									TxtViewTempData.setText(String.valueOf(temp + "°C"));
								}
								if (bSensorEnableValues[2]) {
									LightValue = LightGPIO.getValue();
									light = LightValue.getValue();
									if(String.valueOf(light).equals("1")){
										TxtViewLightData.setText("Off");
									}
									else{
										TxtViewLightData.setText("On");
									}
								}
								if (bSensorEnableValues[3]) {
									hum = readValueH();
									TxtViewHumidityData.setText(String.valueOf(hum) + "%");
								}

							}catch (final GPIOException e) {
								bUpdate = false;
								runOnUiThread(new Runnable() {
									@Override
									public void run() {
										displayError("Error setting GPIO value: " + e.getMessage());
									}
								});
							}
							if(iSendDataTime==9){
								try {
									URL url = new URL("https://api.thingspeak.com/update?api_key=Y64N1A63PRYL402B&field1=" +temp+"&field2="+hum+"&field3="+light+"&field4="+door);
									HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
									urlConnection.getInputStream();
									urlConnection.disconnect();
								}catch(Exception e){}
							}
						}
					});
				}
				try {
					Thread.sleep(100);
					if(iSendDataTime == 10){iSendDataTime = 0;}
					else{iSendDataTime++;}
				} catch (InterruptedException e) {
				}

			}
		}
	};
		SensorUpdateThread.start();
		openInterface();
		double temp = readValueT();
		TxtViewTempData.setText(String.valueOf(temp));
	}

	/**
	 * Stops the sensor's data reading
	 * thread.
	 */
	private void StopSensorThread() {
		if (!bUpdate)
			return;

		bUpdate = false;

		if (SensorUpdateThread != null)
			SensorUpdateThread.interrupt();
	}

	/**
	 * Displays a pop-up with the given error message and exits the application.
	 *
	 * @param errorMessage The error message to display.
	 */
	private void displayError(String errorMessage) {
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setMessage(errorMessage);
		builder.setCancelable(true);

		builder.setPositiveButton(
				"OK",
				new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int id) {
						dialog.cancel();
						finish();
					}
				});
		AlertDialog alert = builder.create();
		alert.show();
	}

	/**
	 * Attempts to open configured I2C interface.
	 */
	private void openInterface() {
		i2cManager = new I2CManager(this);
		i2cInterface = i2cManager.createI2C(2);

		try {
			i2cInterface.open();


		} catch (Exception e) {
			Toast.makeText(this, "Error opening interface: " + e.getMessage(), Toast.LENGTH_SHORT).show();
			e.printStackTrace();
		}
	}

	/**
	 * Attempts to close current I2C interface.
	 */
	private void closeInterface() {
		if (i2cInterface == null)
			return;
		if (i2cInterface.isInterfaceOpen()) {
			try {
				i2cInterface.close();

			} catch (IOException e) {
				Toast.makeText(this, "Error closing interface: " + e.getMessage(), Toast.LENGTH_SHORT).show();
				e.printStackTrace();
			}
		}
	}

	/**
	 * Converts the given integer into a byte array.
	 *
	 * @param value Integer to convert to byte array.
	 * @return The integer as byte array;
	 */
	private static byte[] intToByteArray(int value) {
		return new byte[] {
				(byte)(value >>> 24),
				(byte)(value >>> 16),
				(byte)(value >>> 8),
				(byte)value};
	}

	private Double readValueH() {
		// Check active I2C interface integrity.
		if (i2cInterface == null || !i2cInterface.isInterfaceOpen()) {
			return 0.0;
		}
		try {
			// Set address to read from.
			i2cInterface.write(39,
					new byte[]{intToByteArray(0x0000)[2], intToByteArray(0x0000)[3]});
			// Perform data read.
			byte[] data = i2cInterface.read(39, 256);
			// Draw data.
			hexRows.clear();
			int id = 0;
			ByteArrayInputStream stream = new ByteArrayInputStream(data);

			while (stream.available() > 0) {
				byte[] buffer = new byte[2];
				stream.read(buffer, 0, 2);
				HexRow hexRow = new HexRow(id, buffer);

				if(id == 0) {

					Double result = Double.parseDouble(hexRow.getAsciiString());
					result = Math.round(result * 100) / 100.0;
					return result;

				}
				id++;
			}

		} catch (IOException e) {
			Toast.makeText(this, "Error reading data: " + e.getMessage(), Toast.LENGTH_SHORT).show();
			e.printStackTrace();
		}

		return 1.0;
	}
	private Double readValueT() {
		// Check active I2C interface integrity.
		if (i2cInterface == null || !i2cInterface.isInterfaceOpen()) {
			return 0.0;
		}
		try {
			// Set address to read from.
			i2cInterface.write(39,
					new byte[]{intToByteArray(0x0000)[2], intToByteArray(0x0000)[3]});
			// Perform data read.
			byte[] data = i2cInterface.read(39, 256);
			// Draw data.
			hexRows.clear();
			int id = 0;
			ByteArrayInputStream stream = new ByteArrayInputStream(data);

			while (stream.available() > 0) {
				byte[] buffer = new byte[2];
				stream.read(buffer, 0, 2);
				HexRow hexRow = new HexRow(id, buffer);

				if(id == 1){
					Double result=Double.parseDouble(hexRow.getAsciiString());
					result = Math.round(result*100)/100.0;
					return result;
				}
				id++;
			}

		} catch (IOException e) {
			Toast.makeText(this, "Error reading data: " + e.getMessage(), Toast.LENGTH_SHORT).show();
			e.printStackTrace();
		}

		return 1.0;
	}
}
class HexRow {
	private final int id;
	private final byte[] hexData;

	public HexRow(int id, byte[] hexData) {
		this.id = id;
		this.hexData = hexData;
	}

	public String getAsciiString() {
		if (hexData == null)
			return "";
		String ascii = "";
		String output = "";

		for (byte aHexData : hexData) {
			try {
				String result = "";
				for (byte aData : hexData)
					result += Integer.toString(((aData & 0xff) + 0x100), 16).substring(1);

				ascii += result;
				//ascii += getHexString(new byte[]{aHexData});
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		//int res = Integer.parseInt(ascii, 16);

		if (id == 0){
			output = hexToBinaryHumidity(ascii);
		}
		if (id == 1){
			output = hexToBinaryTemperature(ascii);
		}
		return output;

	}

	String hexToBinaryHumidity(String hex) {
		int i = Integer.parseInt(hex, 16);
		String bin = Integer.toBinaryString(i);
		String sbin = bin.substring(0,13);
		int j = Integer.parseInt(sbin, 2);
		Double k = (j/163.82);
		String dez = Double.toString(k);

		return dez;
	}
	String hexToBinaryTemperature(String hex) {
		int i = Integer.parseInt(hex, 16);
		String bin = Integer.toBinaryString(i);
		String sbin = bin.substring(0,13);
		int j = Integer.parseInt(sbin, 2);
		Double k = ((j/16382.0)*165)-40;
		String dez = Double.toString(k);

		return dez;
	}




}



